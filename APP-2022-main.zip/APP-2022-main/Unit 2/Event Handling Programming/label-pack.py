from tkinter import *
window = Tk()
window.title('Label Using Pack')
window.geometry('300x400')
label = Label(text='Hello').pack()
window.mainloop()