from tkinter import *
window = Tk()
window.title('Button')
window.geometry('300x400')
btn = Button(window,text='Click Me').pack()
window.mainloop()